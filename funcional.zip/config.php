<?php
  define("BASE_URL", 'http://localhost/' . basename(__DIR__) . '/');
 ?>
