<?php require_once('./controller/Logout.php'); ?>
<?php new Logout(); ?>
